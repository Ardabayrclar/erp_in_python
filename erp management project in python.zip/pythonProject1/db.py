import sqlite3
import tkinter
from tkinter import *
import sqlite3
from tkinter import messagebox



class Database:


    def __init__(self, db):
        self.con = sqlite3.connect(db)
        self.cur = self.con.cursor()
        sql = """
        CREATE TABLE IF NOT EXISTS employees(
            id Integer Primary Key,
            urunad text,
            adet text,
            fiyat text,
            email text,
            kur text,
            iletisim text,
            musteri text
        )
        """
        self.cur.execute(sql)
        self.con.commit()

    # Insert Function
    def insert(self, urunad, adet, fiyat, email, kur, iletisim, adres):
        self.cur.execute("insert into employees values (NULL,?,?,?,?,?,?,?)",
                         (urunad, adet,fiyat, email, kur,iletisim, adres))
        self.con.commit()

    # Fetch All Data from DB
    def fetch(self):
        self.cur.execute("SELECT * from employees")
        rows = self.cur.fetchall()
        # print(rows)
        return rows

    # Delete a Record in DB
    def remove(self, id):
        self.cur.execute("delete from employees where id=?", (id,))
        self.con.commit()

    # Update a Record in DB
    def update(self,id, urunad, adet, fiyat, email, kur, iletisim, adres):
        self.cur.execute(
            "update employees set id=?, urunad=?, adet=?, fiyat=?, email=?, kur=?, iletisim=?, adres=? where id=?",
            (id, urunad, adet, fiyat, email, kur, iletisim, adres))
        self.con.commit()





