import random
import tkinter
from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox

root = Tk()
root.title("Fatura Çıkart")
root.geometry("1100x500")

def faturla():

    # label tanımlama işlemleri

    labelad = Label(root, text="                         Ad :")
    labesoyad = Label(root, text="                    Soyad :")
    labeltelefon = Label(root, text="Telefon Numarası :")
    labelurun = Label(root, text="Aldığı Ürün :")
    labeladet = Label(root, text="Adet :")
    labelfiyat = Label(root, text="Toplam Fiyat :")
    labelpersad = Label(root, text="Personel Ad :")
    labelpersoyad = Label(root, text="Personel Soyad :")
    labeltarih = Label(root, text="Tarih :")
    labelbarkod = Label(root,text="Barkod No :")
    labelbarkod1 = Label(root,text="")
    labelbarkod1.grid(row=11,column=5,sticky=W)
    labelbarkod.grid(row=11,column=4,sticky=W)
    label_musteri_bilgi = Label(root, text="Müşteri Bilgileri")
    label_urun_bilgi = Label(root, text="Ürün Bilgileri")
    label_pers_bilgi = Label(root, text="Personel Bilgileri")
    label_satin_alma_tarih = Label(root, text="Satın Alma Tarihi")
    # -----------------------------------------------------------
    labelad1 = Label(root, text="")
    labesoyad1 = Label(root, text="")
    labeltelefon1 = Label(root, text="")
    labelurun1 = Label(root, text="")
    labeladet1 = Label(root, text="")
    labelfiyat1 = Label(root, text="")
    labelpersad1 = Label(root, text="")
    labelpersoyad1 = Label(root, text="")
    labeltarih1 = Label(root, text="")
    labelkesme =Label(root,text="------------------------")
    labelkesme2 = Label(root, text="------------------------")
    labelkesme3 = Label(root, text="------------------------")
    labelkesme4 = Label(root, text="------------------------")
    labelyankesme = Label(root,text="|")
    labelyankesme2 = Label(root, text="|")
    labelyankesme3= Label(root, text="|")
    labelyankesme4 = Label(root, text="|")
    labelyankesme5 = Label(root, text="|")
    labelyankesme6 = Label(root, text="|")
    labelyankesme7 = Label(root, text="|")
    labelyankesme8 = Label(root, text="|")
    labelyankesme9 = Label(root, text="|")
    labelyankesme10 = Label(root, text="|")
    labelyankesme11 = Label(root, text="|")
    labelyankesme12 = Label(root, text="|")
    labelyankesme13 = Label(root, text="|")
    labelyankesme14 = Label(root, text="|")
    labelyankesme15 = Label(root, text="|")
    # -----------------------------------------------------------
    personel_ad = Label(root,text="Personel Ad :")
    personel_ad.grid(row=0,column=5)
    musteri_Ad = Label(root, text="Müşteri Ad :")
    musteri_Ad.grid(row=0, column=0)
    musteri_soyad = Label(root, text="Müşteri Soyad :")
    musteri_soyad.grid(row=1, column=0)
    musteri_tel = Label(root, text="Müşteri Telefon :")
    musteri_tel.grid(row=2, column=0)

    personel = Combobox(root, values=["Seçim Yap", "Burak", "Ali", "Nevzat", "Haluk"])
    personel.grid(row=0, column=6,sticky=W)
    txtmusteri_Ad = Entry(root)

    txtmusteri_Ad.grid(row=0,column=1,sticky=W)
    txtmusteri_soyad = Entry(root)
    txtmusteri_soyad.grid(row=1, column=1,sticky=W)
    txtmusteri_tel = Entry(root)
    txtmusteri_tel.grid(row=2, column=1,sticky=W)

    urun_ad = Label(root,text="Ürün Adı :")
    urun_ad.grid(row=0, column=3,sticky=W)
    urun_adet = Label(root, text="Adet :")
    urun_adet.grid(row=1, column=3,sticky=W)
    urun_fiyat = Label(root, text="Birim Fiyat :")
    urun_fiyat.grid(row=2, column=3,sticky=W)

    tarih_yaz = Label(root, text="Satın alma tarihi :")
    tarih_yaz.grid(row=0, column=7, sticky=W)
    txttarih = Entry(root)
    txttarih.grid(row=0, column=8, sticky=W)


    txturun_adi = Combobox(root, values=["Seçim Yap", "Elmas", "Yakut", "Zümrüt"])
    txturun_adi.grid(row=0, column=4,sticky=W)
    txturun_adet = Entry(root)
    txturun_adet.grid(row=1, column=4,sticky=W)
    txturun_fiyat = Entry(root)
    txturun_fiyat.grid(row=2, column=4,sticky=W)



    def yazdir():
        if  txturun_fiyat.get() == "" or txturun_adet.get() == "" or txtmusteri_Ad.get() =="":
            messagebox.showerror("Boş Alan","Boş Alan Bırakamazsın")
        else:
            barkod_no = random.randint(10000000, 50000000)
            barkod = str(barkod_no)
            adi = str(txtmusteri_Ad.get())
            soyad = str(txtmusteri_soyad.get())
            telefon = str(txtmusteri_tel.get())
            urunadi = str(txturun_adi.get())
            adet = int(txturun_adet.get())
            fiyat = int(txturun_fiyat.get())
            tarih = str(txttarih.get())
            personeladi = str(personel.get())
            urun_adi = str(txturun_adi.get())
            labelad1["text"] = adi
            labesoyad1["text"] = soyad
            labeltelefon1["text"] = telefon
            labelurun1["text"] = urunadi
            labeladet1["text"] = adet
            labelfiyat1["text"] = fiyat * adet
            labeltarih1["text"] = tarih
            labelpersad1["text"] = personeladi
            labelurun1["text"] = urun_adi
            labelbarkod1["text"] = barkod
    btnyazdir = Button(root, text="Fatura Oluştur", command=yazdir)
    btnyazdir.grid(row=4, column=0,pady=20)
    # -----------------------------------------------------------
    labelad1.grid(row=8, column=1, sticky=W)
    labesoyad1.grid(row=9, column=1, sticky=W)
    labeltelefon1.grid(row=10, column=1, sticky=W)
    labelurun1.grid(row=8, column=5, sticky=W)
    labeladet1.grid(row=9, column=5, sticky=W)
    labelfiyat1.grid(row=10, column=5, sticky=W)
    labelpersad1.grid(row=8, column=8, sticky=W)

    labeltarih1.grid(row=8, column=12, sticky=W)
    labelkesme.grid(row=7,column=0)
    labelkesme2.grid(row=7, column=4)
    labelkesme3.grid(row=7, column=7)
    labelkesme4.grid(row=7, column=11)
    labelyankesme.grid(row=6,column=2)
    labelyankesme2.grid(row=7, column=2)
    labelyankesme3.grid(row=8, column=2)
    labelyankesme4.grid(row=9, column=2)
    labelyankesme5.grid(row=10, column=2)
    labelyankesme6.grid(row=7, column=6)
    labelyankesme7.grid(row=8, column=6)
    labelyankesme8.grid(row=9, column=6)
    labelyankesme9.grid(row=10, column=6)
    labelyankesme10.grid(row=6, column=6)
    labelyankesme11.grid(row=7, column=10)
    labelyankesme12.grid(row=8, column=10)
    labelyankesme13.grid(row=9, column=10)
    labelyankesme14.grid(row=10, column=10)
    labelyankesme15.grid(row=6, column=10)

    # ------------------------------------------------------------
    # label.grid tanımlama işlemleri

    labelad.grid(row=8,column=0,sticky=W)
    labesoyad.grid(row=9,column=0,sticky=W)
    labeltelefon.grid(row=10,column=0,sticky=W)
    labelurun.grid(row=8,column=4,sticky=W)
    labeladet.grid(row=9,column=4,sticky=W)
    labelfiyat.grid(row=10,column=4,sticky=W)
    labelpersad.grid(row=8,column=7,sticky=W)

    labeltarih.grid(row=8, column=11, sticky=W)
    label_musteri_bilgi.grid(row=6, column=0, sticky=W)
    label_pers_bilgi.grid(row=6, column=7, sticky=W)
    label_urun_bilgi.grid(row=6, column=4, sticky=W)
    label_satin_alma_tarih.grid(row=6, column=11, sticky=W)

    root.mainloop()
faturla()