from tkinter import *
from tkinter.ttk import Combobox


def col():
    root = Tk()
    root.title("Calculator")
    root.geometry("350x350")

    operation = Combobox(root, values=["Seçim Yap", "Toplama", "Çıkarma", "Bölme", "Çarpma"])
    operation.grid(row=2, column=2, pady=15)

    number1 = Entry(root)
    number1.grid(row=2, column=1)

    number2 = Entry(root)
    number2.grid(row=3, column=1)
    kLabel = Label(root, text="")
    sonucLabel = Label(root, text="Sonuç :")
    kLabel.grid(row=3, column=2)

    def calculate():
        num1 = float(number1.get())
        num2 = float(number2.get())
        kLabel["text"] = ""

        if operation.get() == "Toplama":
            kLabel["text"] = num1 + num2
        elif operation.get() == "Çıkarma":
            kLabel["text"] = num1 - num2
        elif operation.get() == "Çarpma":
            kLabel["text"] = num1 * num2
        elif operation.get() == "Bölme":
            kLabel["text"] = num1 / num2
        elif operation.get() == "":
            kLabel["text"] = "combo boş"
        else:
            kLabel["text"] = "yanlış seçim yaptınız"

    calculate_button = Button(root, text="Hesapla", command=calculate)
    calculate_button.grid(row=5, column=1, pady=15)
    kLabel.grid(row=3, column=3)
    sonucLabel.grid(row=3, column=2)

    root.mainloop()


col()
