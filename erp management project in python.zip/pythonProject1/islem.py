from tkinter import *
from tkinter.ttk import Combobox


def kurhesap():
    root = Tk()

    root.title("Kur Hesapla")
    root.geometry("300x200")

    operation = Combobox(root, values=["Seçim Yap", "Dolar", "Euro", "Ruble", "Sterlin"])
    operation.grid(row=1, column=3, pady=5)


    para = Entry(root)
    para.grid(row=1,column=2)
    sonuclabel=Label(root,text="")
    sonuclabel.grid(row=2,column=3)
    def hesap():

        num1 = float(para.get())

        if  operation.get() == "Dolar":
            sonuclabel["text"] = num1 * 18.55
        elif operation.get() == "Euro":
            sonuclabel["text"] = num1 * 19.15
        elif operation.get() == "Sterlin":
            sonuclabel["text"] = num1 * 22.68
        elif operation.get() == "Ruble":
            sonuclabel["text"] = num1 * 0.27

    don = Button(root, text="Dönüştür", command=hesap)
    don.grid(row=2, column=2)
    root.mainloop()
kurhesap()