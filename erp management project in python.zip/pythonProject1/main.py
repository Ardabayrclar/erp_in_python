import fatura
import file1
import islem
from urunfiyat import urun
from tkinter import *
arda = Tk()
arda.title("İşlem Sayfası")
arda.geometry("250x250")
def gelsin():
    def islem_yap():
        islem.kurhesap()
    def hesapmak():
        file1.col()
    def fiyatdegis():
        urun()
    def faturayap():
        fatura.faturla()
    btnislem_yap = Button(command=islem_yap,text="Kur Hesapla")
    btnhesap = Button(command=hesapmak,text="Hesapmakinesi")
    btnislem_yap.grid(row=0,column=0)
    btnhesap.grid(row=1,column=0)
gelsin()
arda.mainloop()