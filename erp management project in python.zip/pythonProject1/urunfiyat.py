from tkinter import *

pen = Tk()
pen.title("Ürün Fiyatı Hesaplama")
pen.geometry("400x400")


def urun():
    v1 = StringVar(pen)
    v2 = StringVar(pen)
    v3 = StringVar(pen)
    v4 = StringVar(pen)

    hesapLabel = Label(pen, text='0')
    kesmeLabel = Label(pen, text="|")
    kesme2Label = Label(pen, text="|")
    kesme3Label = Label(pen, text="|")
    kesme4Label = Label(pen, text="|")
    kesme5Label = Label(pen, text="|")
    kesme6Label = Label(pen, text="|")
    kesme7Label = Label(pen, text="|")
    kesme8Label = Label(pen, text="|")
    kesme9Label = Label(pen, text="|")
    kesme10Label = Label(pen, text="|")
    kesme11Label = Label(pen, text="|")
    kesme12Label = Label(pen, text="|")
    baslik = Label(pen, text="Taşın Türü")
    baslik4 = Label(pen, text="Taşın Renk")
    baslik2 = Label(pen, text="Taşın Ağrılığı(ct)")
    baslik3 = Label(pen, text="Ödeme Türü")
    fiyat = Label(pen, text="$")

    def hesapla():
        global hesapLabel
        hesapLabel = Label(pen, text='0')
        hesapLabel.grid(row=6, column=2, sticky=W)
        if v1.get() == "onelmas" and v2.get() == "onpembe" and v3.get() == "on2,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3750
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and v2.get() == "onpembe" and v3.get() == "on1,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3250
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and v2.get() == "onpembe" and v3.get() == "on1" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3000
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and v2.get() == "onpembe" and v3.get() == "on2,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 4000
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and v2.get() == "onpembe" and v3.get() == "on1,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3750
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and v2.get() == "onpembe" and v3.get() == "on1" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3500
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and v2.get() == "onmavi" and v3.get() == "on1" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3150
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and "onmavi" == v2.get() and v3.get() == "on1,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3300
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and v2.get() == "onmavi" and v3.get() == "on2,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3450
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and v2.get() == "onmavi" and v3.get() == "on1" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3000
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and v2.get() == "onmavi" and v3.get() == "on1,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3250
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onelmas" and v2.get() == "onmavi" and v3.get() == "on2,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3350
            hesapLabel["text"] = str(sonHesap)
        if v1.get() == "onyakut" and v2.get() == "onpembe" and v3.get() == "on2,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3750
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onpembe" and v3.get() == "on1,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3250
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onpembe" and v3.get() == "on1" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3000
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onpembe" and v3.get() == "on2,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 4000
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onpembe" and v3.get() == "on1,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3759
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onpembe" and v3.get() == "on1" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3500
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onmavi" and v3.get() == "on1" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3150
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and "onmavi" == v2.get() and v3.get() == "on1,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3300
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onmavi" and v3.get() == "on2,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3450
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onmavi" and v3.get() == "on1" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3000
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onmavi" and v3.get() == "on1,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3250
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onmavi" and v3.get() == "on2,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3350
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "onyakut" and v2.get() == "onsari":
            acikla = "Sarı elmas olmaz"
            hesapLabel["text"] = str(acikla)

        if v1.get() == "oncitrin" and v2.get() == "onsari" and v3.get() == "on2,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3750
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and v2.get() == "onsari" and v3.get() == "on1,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3250
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and v2.get() == "onsari" and v3.get() == "on1" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3000
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and v2.get() == "onsari" and v3.get() == "on2,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 4000
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and v2.get() == "onsari" and v3.get() == "on1,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3750
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and v2.get() == "onsari" and v3.get() == "on1" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3500
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and v2.get() == "osari" and v3.get() == "on1" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3150
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and "onmavi" == v2.get() and v3.get() == "on1,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3300
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and v2.get() == "osari" and v3.get() == "on2,5" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3450
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and v2.get() == "osari" and v3.get() == "on1" and v4.get() == "onkredi":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3000
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and v2.get() == "onsari" and v3.get() == "on1,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3250
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and v2.get() == "onsari" and v3.get() == "on2,5" and v4.get() == "onnakit":
            sonHesap = int(hesapLabel["text"])
            sonHesap = sonHesap + 3350
            hesapLabel["text"] = str(sonHesap)
        elif v1.get() == "oncitrin" and (v2.get() == "onpembe" or v2.get() == "onmavi"):
            acikla = "Pembe veya Mavi Citrin olmaz"
            hesapLabel["text"] = str(acikla)

    check1 = Checkbutton(pen, text="Elmas", variable=v1, onvalue="onelmas", offvalue="offelmas")
    check1.deselect()
    check2 = Checkbutton(pen, text="Yakut", variable=v1, onvalue="onyakut", offvalue="offyakut")
    check2.deselect()
    check3 = Checkbutton(pen, text="Citrin", variable=v1, onvalue="oncitrin", offvalue="offcitrin")
    check3.deselect()
    check4 = Checkbutton(pen, text="Mavi", variable=v2, onvalue="onmavi", offvalue="offmavi")
    check4.deselect()
    check5 = Checkbutton(pen, text="Pembe", variable=v2, onvalue="onpembe", offvalue="offpembe")
    check5.deselect()
    check6 = Checkbutton(pen, text="Sarı", variable=v2, onvalue="onsari", offvalue="offsari")
    check6.deselect()
    check7 = Checkbutton(pen, text="2,5", variable=v3, onvalue="on2,5", offvalue="off2,5")
    check7.deselect()
    check8 = Checkbutton(pen, text="1,5", variable=v3, onvalue="on1,5", offvalue="off1,5")
    check8.deselect()
    check9 = Checkbutton(pen, text="1", variable=v3, onvalue="on1", offvalue="off1")
    check9.deselect()
    check10 = Checkbutton(pen, text="Nakit", variable=v4, onvalue="onnakit", offvalue="offnakit")
    check10.deselect()
    check11 = Checkbutton(pen, text="Kredi Kartı", variable=v4, onvalue="onkredi", offvalue="offkredi")
    check11.deselect()
    check12 = Checkbutton(pen, text="Havale", variable=v4, onvalue="onhavale", offvalue="offhavale")
    check12.deselect()

    hesaplabutton = Button(pen, text="Hesapla", command=hesapla)

    check1.grid(row=1, column=0, sticky=W)
    check2.grid(row=2, column=0, sticky=W)
    check3.grid(row=3, column=0, sticky=W)
    check4.grid(row=1, column=2, sticky=W)
    check5.grid(row=2, column=2, sticky=W)
    check6.grid(row=3, column=2, sticky=W)
    check7.grid(row=1, column=4, sticky=W)
    check8.grid(row=2, column=4, sticky=W)
    check9.grid(row=3, column=4, sticky=W)
    check10.grid(row=1, column=6, sticky=W)
    check11.grid(row=2, column=6, sticky=W)
    check12.grid(row=3, column=6, sticky=W)
    hesaplabutton.grid(row=6, column=0, sticky=E)
    hesapLabel.grid(row=6, column=2, sticky=W)
    fiyat.grid(row=6, column=3, sticky=W)
    kesmeLabel.grid(row=0, column=1, sticky=W, padx=10)
    kesme2Label.grid(row=1, column=1, sticky=W, padx=10)
    kesme3Label.grid(row=2, column=1, sticky=W, padx=10)
    kesme4Label.grid(row=3, column=1, sticky=W, padx=10)
    kesme5Label.grid(row=0, column=3, sticky=W, padx=10)
    kesme6Label.grid(row=1, column=3, sticky=W, padx=10)
    kesme7Label.grid(row=2, column=3, sticky=W, padx=10)
    kesme8Label.grid(row=3, column=3, sticky=W, padx=10)
    kesme9Label.grid(row=0, column=5, sticky=W, padx=10)
    kesme10Label.grid(row=1, column=5, sticky=W, padx=10)
    kesme11Label.grid(row=2, column=5, sticky=W, padx=10)
    kesme12Label.grid(row=3, column=5, sticky=W, padx=10)
    baslik.grid(row=0, column=0, sticky=W, pady=10)
    baslik2.grid(row=0, column=4, sticky=W, pady=10)
    baslik3.grid(row=0, column=6, sticky=W, pady=10)
    baslik4.grid(row=0, column=2, sticky=W, pady=10)
    pen.mainloop()

urun()
